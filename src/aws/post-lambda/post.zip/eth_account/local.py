# For backwards compatibility of explicit LocalAccount imports:
from eth_account.signers.local import (  # noqa: F401
    LocalAccount,
)
