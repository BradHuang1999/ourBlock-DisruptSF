class ValidationError(Exception):
    pass


class BadSignature(Exception):
    pass
