def int_to_byte(value: int) -> bytes:
    return bytes([value])
